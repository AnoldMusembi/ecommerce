<?php

return [
    'email' => 'Email',
    'subject' => 'Subject',
    'message' => 'Message',
    'captcha' => 'Captcha',
];
