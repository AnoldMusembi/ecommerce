<?php

return [
    'admin.sliders' => [
        'index' => 'slider::permissions.index',
        'create' => 'slider::permissions.create',
        'edit' => 'slider::permissions.edit',
        'destroy' => 'slider::permissions.destroy',
    ],
];
