<?php

return [
    'index' => 'Index Slider',
    'create' => 'Create Slider',
    'edit' => 'Edit Slider',
    'destroy' => 'Delete Slider',
];
