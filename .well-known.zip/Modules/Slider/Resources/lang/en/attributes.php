<?php

return [
    'caption_1' => 'Caption 1',
    'caption_2' => 'Caption 2',
    'direction' => 'Direction',
    'call_to_action_text' => 'Call to Action Text',
    'call_to_action_url' => 'Call to Action URL',
    'open_in_new_window' => 'Open in new window',
    'caption_1_delay' => 'Delay',
    'caption_1_effect' => 'Effect',
    'caption_2_delay' => 'Delay',
    'caption_2_effect' => 'Effect',
    'call_to_action_delay' => 'Delay',
    'call_to_action_effect' => 'Effect',
    'name' => 'Name',
    'speed' => 'Speed',
    'autoplay' => 'Autoplay',
    'autoplay_speed' => 'Autoplay Speed',
    'fade' => 'Fade',
    'dots' => 'Dots',
    'arrows' => 'Arrows',
];
