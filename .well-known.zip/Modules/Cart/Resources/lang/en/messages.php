<?php

return [
    'out_of_stock' => 'Sorry, the product is out of stock.',
    'not_have_enough_quantity_in_stock' => 'Sorry, we only have :stock in stock.',
    'one_or_more_product_is_out_of_stock' => 'Sorry, one or more product is out of stock.',
    'one_or_more_product_doesn\'t_have_enough_stock' => 'Sorry, one or more product doesn\'t have enough stock.',
];
