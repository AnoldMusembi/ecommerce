<?php

return [
    'admin.importer' => [
        'index' => 'import::permissions.index',
        'create' => 'import::permissions.create',
    ],
];
