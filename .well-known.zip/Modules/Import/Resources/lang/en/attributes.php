<?php

return [
    'csv_file' => 'CSV File',
    'import_type' => 'Import Type',
];
