<?php

return [
    'id' => 'ID',
    'name' => 'Name',
    'slug' => 'URL',
    'is_searchable' => 'Searchable',
    'is_active' => 'Status',
];
