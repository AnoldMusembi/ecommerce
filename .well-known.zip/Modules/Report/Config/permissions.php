<?php

return [
    'admin.reports' => [
        'index' => 'report::permissions.index',
    ],
];
