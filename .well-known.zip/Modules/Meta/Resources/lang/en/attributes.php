<?php

return [
    'meta_title' => 'Meta Title',
    'meta_description' => 'Meta Description',
];
