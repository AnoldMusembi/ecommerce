<?php

namespace Modules\Payment;

interface HasTransactionReference
{
    public function getTransactionReference();
}
