<?php

namespace Modules\Payment;

use Modules\Support\Manager;

class GatewayManager extends Manager
{
    //
}
