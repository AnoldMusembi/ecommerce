<?php

return [
    'only_supports_inr' => 'Instamojo only supports INR currency.',
];
