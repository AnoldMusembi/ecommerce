<?php

return [
    'image_has_been_added' => 'Image has been added.',
];
