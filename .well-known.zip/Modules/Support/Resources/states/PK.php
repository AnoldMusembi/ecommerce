<?php

return [
    'JK' => 'Azad Kashmir',
    'BA' => 'Balochistan',
    'TA' => 'FATA',
    'GB' => 'Gilgit Baltistan',
    'IS' => 'Islamabad Capital Territory',
    'KP' => 'Khyber Pakhtunkhwa',
    'PB' => 'Punjab',
    'SD' => 'Sindh',
];
