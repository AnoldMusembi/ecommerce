<?php

return [
    'PR1' => 'Province 1',
    'PR2' => 'Province 2',
    'PR3' => 'Bagmati',
    'PR4' => 'Gandaki',
    'PR5' => 'Lumbini',
    'PR6' => 'Karnali',
    'PR7' => 'Sudurpaschim',
];
