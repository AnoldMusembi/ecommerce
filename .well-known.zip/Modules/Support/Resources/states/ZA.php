<?php

return [
    'EC' => 'Eastern Cape',
    'FS' => 'Free State',
    'GP' => 'Gauteng',
    'KZN' => 'KwaZulu-Natal',
    'LP' => 'Limpopo',
    'MP' => 'Mpumalanga',
    'NC' => 'Northern Cape',
    'NW' => 'North West',
    'WC' => 'Western Cape',
];
