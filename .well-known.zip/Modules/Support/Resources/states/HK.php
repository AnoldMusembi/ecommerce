<?php

return [
    'HONG KONG' => 'Hong Kong Island',
    'KOWLOON' => 'Kowloon',
    'NEW TERRITORIES' => 'New Territories',
];
