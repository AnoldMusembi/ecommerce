<?php

return [
    'B' => 'Chuquisaca',
    'H' => 'Beni',
    'C' => 'Cochabamba',
    'L' => 'La Paz',
    'O' => 'Oruro',
    'N' => 'Pando',
    'P' => 'Potosí',
    'S' => 'Santa Cruz',
    'T' => 'Tarija',
];
