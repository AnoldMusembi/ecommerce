<?php

return [
    'admin.brands' => [
        'index' => 'brand::permissions.index',
        'create' => 'brand::permissions.create',
        'edit' => 'brand::permissions.edit',
        'destroy' => 'brand::permissions.destroy',
    ],
];
