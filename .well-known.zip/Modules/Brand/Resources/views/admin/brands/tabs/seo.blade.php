<div class="row">
    <div class="col-md-8">
        @include('meta::admin.meta_fields', ['entity' => $brand])
    </div>
</div>
