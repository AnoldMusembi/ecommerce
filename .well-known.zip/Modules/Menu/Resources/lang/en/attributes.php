<?php

return [
    'name' => 'Name',
    'type' => 'Type',
    'url' => 'URL',
    'icon' => 'Icon',
    'category_id' => 'Category',
    'page_id' => 'Page',
    'parent_id' => 'Parent Menu Item',
    'target' => 'Target',
    'is_fluid' => 'Fluid Menu',
    'is_active' => 'Status',
];
