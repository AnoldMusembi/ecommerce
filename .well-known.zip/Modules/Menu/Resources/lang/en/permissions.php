<?php

return [
    'menus' => [
        'index' => 'Index Menus',
        'create' => 'Create Menus',
        'edit' => 'Edit Menus',
        'destroy' => 'Delete Menus',
    ],
    'menu_items' => [
        'index' => 'Index Menu Items',
        'create' => 'Create Menu Items',
        'edit' => 'Edit Menu Items',
        'destroy' => 'Delete Menu Items',
    ],
];
