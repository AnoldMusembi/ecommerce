<?php

return [
    'menus' => 'Menus',
];
