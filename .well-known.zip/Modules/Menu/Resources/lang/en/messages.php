<?php

return [
    'menu_item_deleted' => 'Menu item has been deleted.',
    'menu_items_order_updated' => 'Menu items order has been updated.',
];
